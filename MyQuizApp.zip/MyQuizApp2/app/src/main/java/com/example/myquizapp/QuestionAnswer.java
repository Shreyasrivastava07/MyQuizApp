package com.example.myquizapp;

public class QuestionAnswer {
    public static String question[]={
            "Which company owns Android?",
            "Which one is not a programming language?",
            "Who is the Prime Minister of India?"



    };
    public static String choices[][]={
            {"Google","Apple","Nokia","samsung"},
            {"Java","Kotlin","Notepad","Python"},
            {"Rahul Gandhi","Narendra Modi","Akhilesh Yadav","Amit Shah"}

    };

    public static String correctAnswers[]={
            "Google",
            "Notepad",
            "Narendra Modi"


    };



}
